self.MAT_CACHE_NAME = "mat-codex-b9bbcb6a09d367ca";
